Credits
-------
This pack can be modified and distributed under the terms of CC BY 4.0 licence.
The original author is Sylith, with additional modifications by shaw and
IOI-655362.

The original textures have been extended with some more hair colour variations,
removed beards etc.) and have some other tweaks (removed eye shadows, fixed some
textures to match better at the back of a head, greener skin ...).

Some of modifications made by IOI-655362 in Diverse Kerbal Heads pack (eye/beard
shadows, skin tones ...) were later added to this pack.
